/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["managepr/managepr/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
