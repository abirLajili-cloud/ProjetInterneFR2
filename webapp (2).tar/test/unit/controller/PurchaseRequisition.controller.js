/*global QUnit*/

sap.ui.define([
	"managepr/managepr/controller/PurchaseRequisition.controller"
], function (Controller) {
	"use strict";

	QUnit.module("PurchaseRequisition Controller");

	QUnit.test("I should test the PurchaseRequisition controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});
