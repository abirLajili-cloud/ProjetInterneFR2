sap.ui.define([
	"managepr/managepr/test/unit/controller/PurchaseRequisition.controller"
], function () {
	"use strict";
});
