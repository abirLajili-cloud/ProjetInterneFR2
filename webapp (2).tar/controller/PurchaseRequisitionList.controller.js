sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/model/json/JSONModel",
  "sap/m/MessageBox",
  "sap/m/MessageToast",

  // Items popup UI
  "sap/m/VBox",
  "sap/m/HBox",
  "sap/m/Title",
  "sap/m/ObjectStatus",
  "sap/ui/core/Icon",
  "sap/ui/layout/form/SimpleForm",
  "sap/m/Label",
  "sap/m/Text"
], function (
  Controller, JSONModel, MessageBox, MessageToast,
  VBox, HBox, Title, ObjectStatus, Icon,
  SimpleForm, Label, Text
) {
  "use strict";

  return Controller.extend("managepr.managepr.controller.PurchaseRequisitionList", {

    onInit: function () {
      this.getView().setModel(new JSONModel({
        busy: false,
        pageSize: 10,
        page: 1,
        total: 0,
        totalPages: 1,
        items: [],
        query: ""
      }), "listModel");

      this.getView().setModel(new JSONModel({
        busy: false,
        prId: "",
        items: []
      }), "itemsModel");

      this._loadPage(1);
    },

    // ===================== PR LIST =====================
    _buildUrl: function () {
      const oVM = this.getView().getModel("listModel");
      const iPageSize = oVM.getProperty("/pageSize");
      const iPage = oVM.getProperty("/page");
      const sQuery = (oVM.getProperty("/query") || "").trim();
      const iSkip = (iPage - 1) * iPageSize;

      let sUrl =
        "/sap/opu/odata/sap/ZSB_PR/ZI_PR" +
        "?$format=json" +
        "&sap-language=EN" +
        "&$top=" + encodeURIComponent(iPageSize) +
        "&$skip=" + encodeURIComponent(iSkip) +
        "&$orderby=" + encodeURIComponent("PurchaseRequisition desc") +
        "&$inlinecount=allpages";

      // ✅ Exclude PR starting with '3'
      // If startswith is not supported in your GW, we can change it.
      const aFilters = ["not startswith(PurchaseRequisition,'3')"];

      if (sQuery) {
        const esc = sQuery.replace(/'/g, "''").toLowerCase();
        aFilters.push(
          "(" +
            "substringof('" + esc + "', tolower(PurchaseRequisition)) or " +
            "substringof('" + esc + "', tolower(PurReqnDescription)) or " +
            "substringof('" + esc + "', tolower(PurchaseRequisitionType))" +
          ")"
        );
      }

      if (aFilters.length) {
        sUrl += "&$filter=" + encodeURIComponent(aFilters.join(" and "));
      }

      return sUrl;
    },

    _loadPage: async function (iPage) {
      const oVM = this.getView().getModel("listModel");
      oVM.setProperty("/busy", true);

      try {
        oVM.setProperty("/page", iPage);

        const resp = await fetch(this._buildUrl(), {
          method: "GET",
          headers: { "Accept": "application/json" },
          credentials: "include"
        });

        if (!resp.ok) {
          const txt = await resp.text();
          throw new Error(`READ failed (${resp.status}): ${txt}`);
        }

        const data = await resp.json();
        const a = data?.d?.results || [];

        const sCount = data?.d?.__count;
        const iTotal = sCount ? parseInt(sCount, 10) : a.length;

        const iPageSize = oVM.getProperty("/pageSize");
        const iTotalPages = Math.max(1, Math.ceil(iTotal / iPageSize));

        oVM.setProperty("/items", a);
        oVM.setProperty("/total", iTotal);
        oVM.setProperty("/totalPages", iTotalPages);

      } catch (e) {
        MessageBox.error("Erreur de lecture : " + e.message);
      } finally {
        oVM.setProperty("/busy", false);
      }
    },

    onRefresh: function () {
      this._loadPage(1);
    },

    onSearch: function (oEvent) {
      const sQuery = (oEvent.getParameter("query") || "").trim();
      const oVM = this.getView().getModel("listModel");
      oVM.setProperty("/query", sQuery);
      this._loadPage(1);
    },

    onPrevPage: function () {
      const oVM = this.getView().getModel("listModel");
      const p = oVM.getProperty("/page");
      if (p <= 1) return;
      this._loadPage(p - 1);
    },

    onNextPage: function () {
      const oVM = this.getView().getModel("listModel");
      const p = oVM.getProperty("/page");
      const tp = oVM.getProperty("/totalPages");
      if (p >= tp) return;
      this._loadPage(p + 1);
    },

    onLogout: function () {
      const oSession = this.getOwnerComponent().getModel("session");
      if (oSession) oSession.setProperty("/user", null);
      MessageToast.show("Disconnected");
      this.getOwnerComponent().getRouter().navTo("RouteAuth", {}, true);
    },

    // ===================== ITEMS POPUP =====================
    onOpenItems: async function (oEvent) {
      const oCtx = oEvent.getSource().getBindingContext("listModel");
      const sPrId = oCtx?.getProperty("PurchaseRequisition");

      if (!sPrId) {
        MessageToast.show("PR ID not found.");
        return;
      }

      const oItemsVM = this.getView().getModel("itemsModel");
      oItemsVM.setProperty("/busy", true);
      oItemsVM.setProperty("/prId", sPrId);
      oItemsVM.setProperty("/items", []);

      try {
        const sItemsEntitySet = "ZI_PR_ITEM"; // change if needed

        const sUrl =
          "/sap/opu/odata/sap/ZSB_PR/" + sItemsEntitySet +
          "?$format=json&sap-language=EN&$filter=" +
          encodeURIComponent(
            "PurchaseRequisition eq '" + String(sPrId).replace(/'/g, "''") + "'"
          );

        const resp = await fetch(sUrl, {
          method: "GET",
          headers: { "Accept": "application/json" },
          credentials: "include"
        });

        if (!resp.ok) {
          const txt = await resp.text();
          throw new Error(`READ items failed (${resp.status}): ${txt}`);
        }

        const data = await resp.json();
        const aItems = data?.d?.results || [];

        oItemsVM.setProperty("/items", aItems);

        // open dialog
        this.byId("itemsDialog").open();

        // render
        this._renderItemsCards();

      } catch (e) {
        MessageBox.error("Erreur de lecture items : " + e.message);
      } finally {
        oItemsVM.setProperty("/busy", false);
      }
    },

    onCloseItemsDialog: function () {
      this.byId("itemsDialog").close();
    },

    _renderItemsCards: function () {
      const oItemsVM = this.getView().getModel("itemsModel");
      const aItems = oItemsVM.getProperty("/items") || [];

      const oScroll = this.byId("itemsScroll");
      if (!oScroll) return;

      // ✅ FIX: ScrollContainer => content (plural)
      if (oScroll.removeAllContent) {
        oScroll.removeAllContent();
      } else if (oScroll.destroyContent) {
        oScroll.destroyContent();
      }

      const oWrapper = new VBox({ width: "100%" }).addStyleClass("itemsCardsWrapper");

      if (!aItems.length) {
        oWrapper.addItem(
          new Text({ text: "No items found for this PR." }).addStyleClass("itemsEmptyText")
        );
        oScroll.addContent(oWrapper);
        return;
      }

      const aExclude = ["Delete_mc", "Update_mc", "to_Header", "__metadata"];

      aItems.forEach((it, idx) => {
        const sItemNo = it.PurchaseRequisitionItem || String(idx + 1);

        const oCard = new VBox().addStyleClass("itemsCard");

        const oHeader = new HBox({
          justifyContent: "SpaceBetween",
          alignItems: "Center"
        }).addStyleClass("itemsCardHeader");

        const oLeft = new HBox({ alignItems: "Center" }).addStyleClass("itemsCardHeaderLeft");
        oLeft.addItem(new Icon({ src: "sap-icon://cart" }).addStyleClass("itemsCardIcon"));
        oLeft.addItem(new Title({
          level: "H5",
          text: "Item " + sItemNo
        }).addStyleClass("itemsCardTitle"));

        const oBadge = new ObjectStatus({
          text: it.Material || "—",
          state: "Information",
          icon: "sap-icon://product"
        }).addStyleClass("itemsCardBadge");

        oHeader.addItem(oLeft);
        oHeader.addItem(oBadge);

        const oForm = new SimpleForm({
          editable: false,
          layout: "ResponsiveGridLayout",
          columnsL: 2,
          columnsM: 2,
          labelSpanL: 4,
          labelSpanM: 4
        }).addStyleClass("itemsForm");

        Object.keys(it).forEach((k) => {
          if (aExclude.includes(k)) return;

          const v = it[k];
          let sVal = "";
          if (v === null || v === undefined) sVal = "";
          else if (typeof v === "object") sVal = JSON.stringify(v);
          else sVal = String(v);

          oForm.addContent(new Label({ text: k }).addStyleClass("itemsLabel"));
          oForm.addContent(new Text({ text: sVal, wrapping: true }).addStyleClass("itemsValue"));
        });

        const oBody = new VBox().addStyleClass("itemsCardBody");
        oBody.addItem(oForm);

        oCard.addItem(oHeader);
        oCard.addItem(oBody);

        oWrapper.addItem(oCard);
      });

      oScroll.addContent(oWrapper);
    },
    onCreatePR: function () {
  const oRouter = this.getOwnerComponent().getRouter();
  oRouter.navTo("RoutePurchaseRequisition");
}


  });
});
