sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/model/json/JSONModel",
  "sap/m/MessageToast",
  "sap/m/MessageBox"
], function (Controller, JSONModel, MessageToast, MessageBox) {
  "use strict";

  return Controller.extend("managepr.managepr.controller.Auth", {

    onInit: function () {
      this.getView().setModel(new JSONModel({
        login: "",
        password: ""
      }), "local");
    },

    onLogin: function () {
      const oLocal = this.getView().getModel("local");
      const sLogin = (oLocal.getProperty("/login") || "").trim();
      const sPass  = (oLocal.getProperty("/password") || "").trim();

      // ✅ always take models from component
      const oMock = this.getOwnerComponent().getModel("mockData");
      const oSession = this.getOwnerComponent().getModel("session");

      if (!oMock) {
        MessageBox.error("Model 'mockData' not loaded. Fix Component.js (load data.json).");
        return;
      }
      if (!oSession) {
        MessageBox.error("Model 'session' not found. Fix Component.js (create session model).");
        return;
      }

      const aUsers = oMock.getProperty("/users");
      if (!Array.isArray(aUsers)) {
        MessageBox.error("data.json invalid: expected array at /users.");
        return;
      }

      const oUser = aUsers.find(u => u.login === sLogin && u.password === sPass);

      if (!oUser) {
        MessageBox.error("Invalid login or password!");
        return;
      }

      oSession.setProperty("/user", oUser);
      MessageToast.show("Welcome " + oUser.id);

      const oRouter = this.getOwnerComponent().getRouter();
      switch (oUser.role) {
        case "ADMIN":    oRouter.navTo("RouteAdmin"); break;
        case "SUPPLIER": oRouter.navTo("RouteSupplier"); break;
        case "CUSTOMER": oRouter.navTo("RoutePurchaseRequisitionList"); break;
        default: MessageBox.error("Unknown role: " + oUser.role);
      }
    }

  });
});
