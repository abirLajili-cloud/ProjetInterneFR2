sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/model/json/JSONModel",
  "sap/m/MessageToast",
  "sap/m/MessageBox"
], function (Controller, JSONModel, MessageToast, MessageBox) {
  "use strict";

  return Controller.extend("managepr.managepr.controller.PurchaseRequisition", {

    onInit: function () {
      const oData = {
        PurchaseRequisitionType: "NB",
        PurReqnDescription: "linked",
        Items: [{
          Material: "AC-001",
          PurchaseRequisitionItemText: "text itm",
          Plant: "1210",
          BaseUnit: "PC",                 // ✅ le champ attendu par ton service
          RequestedQuantity: "2",
          Supplier: "1000070",
          PurReqnItemCurrency: "EUR",
          PurchaseRequisitionPrice: "12",
          RequisitionerName: "ImeneZarrami"
        }]
      };

      this.getView().setModel(new JSONModel(oData), "purchaseModel");
    },

    onAddItem: function () {
      const oModel = this.getView().getModel("purchaseModel");
      const aItems = oModel.getProperty("/Items") || [];

      aItems.push({
        Material: "",
        PurchaseRequisitionItemText: "",
        Plant: "",
        BaseUnit: "PC",
        RequestedQuantity: "1",
        Supplier: "",
        PurReqnItemCurrency: "EUR",
        PurchaseRequisitionPrice: "0",
        RequisitionerName: ""
      });

      oModel.setProperty("/Items", aItems);
    },

    onDeleteItem: function (oEvent) {
      const oCtx = oEvent.getSource().getBindingContext("purchaseModel");
      const sPath = oCtx.getPath();              // ex: "/Items/0"
      const iIndex = parseInt(sPath.split("/").pop(), 10);

      const oModel = oCtx.getModel();
      const aItems = oModel.getProperty("/Items") || [];
      aItems.splice(iIndex, 1);
      oModel.setProperty("/Items", aItems);
    },

    _fetchCsrfToken: async function () {
      // ✅ même langage que le POST
      const sServiceRoot = "/sap/opu/odata/sap/ZSB_PR/?sap-language=EN";

      const resp = await fetch(sServiceRoot, {
        method: "GET",
        headers: {
          "X-CSRF-Token": "Fetch",
          "Accept": "application/json"
        },
        credentials: "include"
      });

      if (!resp.ok) {
        const txt = await resp.text();
        throw new Error(`CSRF fetch failed (${resp.status}): ${txt}`);
      }

      const sToken = resp.headers.get("x-csrf-token");
      if (!sToken) {
        throw new Error("CSRF token header not returned by backend.");
      }
      return sToken;
    },

    onCreatePR: async function () {
      const oView = this.getView();
      const oLocal = oView.getModel("purchaseModel");

      if (!oLocal) {
        MessageBox.error("purchaseModel not found.");
        return;
      }

      const oData = oLocal.getData();

      if (!oData.PurchaseRequisitionType || !oData.PurReqnDescription) {
        MessageBox.warning("Veuillez remplir Type et Description.");
        return;
      }
      if (!oData.Items || oData.Items.length === 0) {
        MessageBox.warning("Veuillez ajouter au moins un item.");
        return;
      }

      // ✅ Payload conforme au Swagger qui marche (BaseUnit, pas BaseUnitISOCode)
      const oPayload = {
        PurReqnDescription: oData.PurReqnDescription,
        PurchaseRequisitionType: oData.PurchaseRequisitionType,
        to_Items: {
          results: oData.Items.map(it => ({
            Material: it.Material,
            PurchaseRequisitionItemText: it.PurchaseRequisitionItemText,
            Plant: it.Plant,
            BaseUnit: it.BaseUnit, // ✅
            RequestedQuantity: String(it.RequestedQuantity),
            Supplier: it.Supplier,
            PurReqnItemCurrency: it.PurReqnItemCurrency,
            PurchaseRequisitionPrice: String(it.PurchaseRequisitionPrice),
            RequisitionerName: it.RequisitionerName
          }))
        }
      };

      console.log("Payload envoyé :", JSON.stringify(oPayload, null, 2));
      oView.setBusy(true);

      try {
        const sToken = await this._fetchCsrfToken();
        console.log("CSRF token fetched:", sToken);

        // ✅ Forcer sap-language=EN pour éviter l’erreur “PC pas créé en FR”
        const sUrl = "/sap/opu/odata/sap/ZSB_PR/ZI_PR?sap-language=EN";

        const resp = await fetch(sUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "X-CSRF-Token": sToken
          },
          credentials: "include",
          body: JSON.stringify(oPayload)
        });

        const text = await resp.text();
        if (!resp.ok) {
          throw new Error(`Erreur SAP (${resp.status}): ${text}`);
        }

        // OData V2 renvoie souvent { d: {...} }
        const result = text ? JSON.parse(text) : {};
        console.log("Réponse du serveur :", result);

        const createdId =
          result?.d?.PurchaseRequisition ||
          result?.d?.PurchaseRequisitionID ||
          result?.d?.PurchaseRequisitionNumber;

        MessageToast.show(createdId ? `PR créée: ${createdId}` : "PR créée avec succès ✅");

      } catch (err) {
        console.error("Erreur lors de la création :", err.message);

        // Essaye d’extraire un message SAP lisible
        let sNice = err.message;
        try {
          const jsonStart = err.message.indexOf("{");
          if (jsonStart >= 0) {
            const oErr = JSON.parse(err.message.slice(jsonStart));
            const sSapMsg = oErr?.error?.message?.value;
            if (sSapMsg) sNice = sSapMsg;
          }
        } catch (e) { /* ignore */ }

        MessageBox.error("Erreur lors de la création : " + sNice);
      } finally {
        oView.setBusy(false);
      }
    },
    onBackToList: function () {
  this.getOwnerComponent().getRouter().navTo("RoutePurchaseRequisitionList", {}, true);
}

  });
});
