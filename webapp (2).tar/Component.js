sap.ui.define([
  "sap/ui/core/UIComponent",
  "sap/ui/model/json/JSONModel",
  "managepr/managepr/model/models"
], function (UIComponent, JSONModel, models) {
  "use strict";

  return UIComponent.extend("managepr.managepr.Component", {
    metadata: {
      manifest: "json",
      interfaces: ["sap.ui.core.IAsyncContentCreation"]
    },

    init: function () {
      UIComponent.prototype.init.apply(this, arguments);

      // Device model
      this.setModel(models.createDeviceModel(), "device");

      // ✅ Load mock data.json
      // IMPORTANT: data.json must be in /webapp/data.json
      var oMock = new JSONModel();
      oMock.loadData(sap.ui.require.toUrl("managepr/managepr/data.json"));
      this.setModel(oMock, "mockData");

      // ✅ Session model
      var oSession = new JSONModel({ user: null, isLoggedIn: false });
      this.setModel(oSession, "session");

      // Router
      this.getRouter().initialize();
    }
  });
});
