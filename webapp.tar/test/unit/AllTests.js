sap.ui.define([
	"project1/test/unit/controller/welcome.controller"
], function () {
	"use strict";
});
